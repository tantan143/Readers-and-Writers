package application;

import java.util.concurrent.Semaphore;

import javafx.application.Platform;
import javafx.scene.control.Button;

public class Database implements RWLock{
	private int readerCount;  // the number of active readers
    private Semaphore mutex;  // controls access to readerCount
    private Semaphore db;     // controls access to the database
    private Semaphore serviceQueue;
    private Semaphore s1;
    private Semaphore s2;
    public static ReaderWriterSolution rw = new ReaderWriterSolution();
     public Database() {
       readerCount = 0;
       mutex = new Semaphore(1);
       db = new Semaphore(1);
       serviceQueue = new Semaphore(1);
       s1 = new Semaphore(1);
       s2= new Semaphore(1);
    }
     	
     public void acquireReadLock(int readerNum) {
       try{
    	  /* s2.acquire();
    	   rw.Ta.appendText("reader " + " wants to read."+ "\n");
    	   s2.release();*/
    	   serviceQueue.acquire();
       //mutual exclusion for readerCount 
          mutex.acquire();
       }catch (InterruptedException e) {}
    
       ++readerCount;
    
    // if I am the first reader tell all others
    // that the database is being read
       if (readerCount == 1){
          try{
             db.acquire();
          }catch (InterruptedException e) {}
       }
       try {
		s1.acquire();
	} catch (InterruptedException e1) {
		// TODO Auto-generated catch block
		//e1.printStackTrace();
	}
       if(!rw.vb1.getChildren().isEmpty()) {
    	   String x= ((Button)rw.vb1.getChildren().get(0)).getText();
      Platform.runLater(()->{
    	  rw.vb2.getChildren().add((Button)rw.vb1.getChildren().get(0));
		});
      
      try {
 			Thread.sleep(1000);
 		}catch (InterruptedException e) {}
      s1.release();
      System.out.println(x + " is reading. Reader count = " + readerCount);
      rw.Ta.appendText(x+ " is reading. Reader count = " + readerCount+" \n");
      serviceQueue.release();
      //mutual exclusion for readerCount
      mutex.release();
       }
       
    }
 
     public void releaseReadLock(int readerNum) {
       try{
       //mutual exclusion for readerCount
          mutex.acquire();
       }catch (InterruptedException e) {}
       try {
		s1.acquire();
	} catch (InterruptedException e1) {}
       if(!rw.vb2.getChildren().isEmpty()) {
    	   String x =((Button)rw.vb2.getChildren().get(0)).getText();
       Platform.runLater(()->{
     	  rw.vb1.getChildren().add((Button)rw.vb2.getChildren().get(0));
 		});
       try {
  			Thread.sleep(1000);
  		} catch (InterruptedException e) {
  			// TODO Auto-generated catch block
  	//		e.printStackTrace();
  		}
       s1.release();
       --readerCount;
    
    // if I am the last reader tell all others
    // that the database is no longer being read
       if (readerCount == 0){
          db.release();
       }
       rw.Ta.appendText(x + " is done reading. Reader count = " + readerCount+" \n");
       System.out.println(x + " is done reading. Reader count = " + readerCount);
       }
       
    
    //mutual exclusion for readerCount
       mutex.release();
    }
 
     public void acquireWriteLock(int writerNum) {
       try{
    	 /*  s2.acquire();
    	   rw.Ta.appendText("writer " + " wants to write."+ "\n");
    	   s2.release();*/
    	   serviceQueue.acquire();
          db.acquire();
       }catch (InterruptedException e) {}
       serviceQueue.release();
       try {
		s1.acquire();
	} catch (InterruptedException e1) {
		// TODO Auto-generated catch block
	//	e1.printStackTrace();
	}
       if(!rw.vb3.getChildren().isEmpty()) {
    	   String x =((Button)rw.vb3.getChildren().get(0)).getText();
    	   Platform.runLater(()->{
       rw.vb2.getChildren().add((Button)rw.vb3.getChildren().get(0));
       });
    	   try {
      			Thread.sleep(1000);
      		} catch (InterruptedException e) {
      			// TODO Auto-generated catch block
     // 			e.printStackTrace();
      		}
       System.out.println(x+  " is writing.");
       rw.Ta.appendText(x+ " is writing."+ " \n");
    }
       s1.release();
  }
     public void releaseWriteLock(int writerNum) {
    	 try {
			s1.acquire();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
		//	e1.printStackTrace();
		}
    	 if(!rw.vb2.getChildren().isEmpty()) {
    		 String x =((Button)rw.vb2.getChildren().get(0)).getText();
    		Platform.runLater(()->{
    	 rw.vb3.getChildren().add((Button)rw.vb2.getChildren().get(0));
    	 });
    		try {
       			Thread.sleep(1000);
       		} catch (InterruptedException e) {
       			// TODO Auto-generated catch block
     //  			e.printStackTrace();
       		}
       System.out.println(x+ " is done writing.");
       rw.Ta.appendText(x+ " is done writing."+" \n");
       db.release();
    }
    	 s1.release();
 
     }
}
