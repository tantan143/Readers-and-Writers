package application;

import java.io.IOException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class ReaderWriterSolution  extends Application{
	public static final int NUM_OF_READERS = 10;
    public static final int NUM_OF_WRITERS = 10;
    @FXML
  	public static  VBox vb1 = new VBox(); 
  	@FXML
  	public static VBox vb2 = new VBox(); 
  	@FXML
  	public static VBox vb3 = new VBox(); 
  	@FXML
  	public static VBox vb4 = new VBox(); 
  	@FXML
  	public static TextArea Ta = new TextArea();
  	@FXML
    Button btn1 =new Button();
    @FXML
    Button btn2 =new Button();
    @FXML
    HBox hb = new HBox();
    public int i=1,k=1;
    RWLock database = new Database();
    
    Thread[] readerArray = new Thread[NUM_OF_READERS];
    Thread[] writerArray = new Thread[NUM_OF_WRITERS];
 
    public void start(Stage primaryStage) {
    	try {
    		
    		StackPane root = new StackPane();
    		FlowPane r = new FlowPane();
			btn1.setText("them reader");
			btn2.setText("them writer");
			btn1.setTextFill(Color.web("#0076a3"));
			btn2.setTextFill(Color.web("#d00d0d"));

			vb1.setAlignment(Pos.BASELINE_LEFT);
			vb2.setAlignment(Pos.BASELINE_CENTER);
			vb3.setAlignment(Pos.BASELINE_RIGHT);

			r.getChildren().addAll(btn1,btn2,Ta);
			r.setAlignment(Pos.BOTTOM_CENTER);
			btn1.setOnAction(e->{
				Button bt =new Button();
				bt.setText("reader "+i);
				bt.setTextFill(Color.web("#0076a3"));
				readerArray[i] = new Thread(new Reader(i, database));
		         readerArray[i].start();
				i++;
				vb1.getChildren().add(bt);
			});
			btn2.setOnAction(e->{
				Button bt = new Button();
				bt.setText("writer "+k);
				bt.setTextFill(Color.web("#d00d0d"));
				writerArray[k] = new Thread(new Writer(k, database));
		        writerArray[k].start();
				k++;
				vb3.getChildren().add(bt);
			});
			root.getChildren().addAll(vb1,vb3,vb2,r);
			Scene scene =new Scene(root,600,400);
			primaryStage.setScene(scene);
			primaryStage.show();
			
		} catch(Exception e) {}
 
    }
    public static void main(String[] args) {
		launch(args);
	}
}
