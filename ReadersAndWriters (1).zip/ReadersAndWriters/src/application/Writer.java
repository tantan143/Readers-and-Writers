package application;

public class Writer implements Runnable{
	private RWLock database;
    private int writerNum;
    public  ReaderWriterSolution rw = new ReaderWriterSolution();
     public Writer(int w, RWLock d) {
       writerNum = w;
       database = d;
    }
 
     public void run() {
       while (true){
    	   try {
     			Thread.sleep(1000);
     		} catch (InterruptedException e) {}
          System.out.println("writer " + writerNum + " wants to write.");
          database.acquireWriteLock(writerNum);
       
       // you have access to write to the database
       // write for awhile ...
          try {
    			Thread.sleep(1000);
    		} catch (InterruptedException e) {}
       
          database.releaseWriteLock(writerNum);
       }
    }
}