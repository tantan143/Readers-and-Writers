package application;

public class Reader implements Runnable{
	private RWLock database;
    private int readerNum;
    
     public Reader(int readerNum, RWLock database) {
       this.readerNum = readerNum;
       this.database = database;
    }
     public  ReaderWriterSolution rw = new ReaderWriterSolution();
     public void run() {
       while (true) {
    	   try {
     			Thread.sleep(1000);
     		} catch (InterruptedException e) {}
          System.out.println("reader " + readerNum + " wants to read.");
          database.acquireReadLock(readerNum);
       
       // you have access to read from the database
       // let's read for awhile .....
          try {
    			Thread.sleep(1000);
    		} catch (InterruptedException e) {
    		}
       
          database.releaseReadLock(readerNum);
       }
    }
}
